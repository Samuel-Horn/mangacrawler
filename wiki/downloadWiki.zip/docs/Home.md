Download manga from many popular sites.

Currently supported sites:

* [Anime Source](http://www.anime-source.com)
* [Animea](http://manga.animea.net)
* [Kissmanga](http://kissmanga.com)
* [Manga Fox](http://mangafox.me)
* [Manga Here](http://www.mangahere.com)
* [Manga Reader](http://www.mangareader.net)
* [Manga Share](http://read.mangashare.com)
* [Manga Stream](http://mangastream.com)
* [Manga Volume](http://www.mangavolume.com)
* [Spectrum Nexus](http://www.thespectrum.net)
* [Starkana](http://www.starkana.com)
* [Unix Manga](http://unixmanga.com)

![](Home_1.png)
There is resize control beetwen series and chapters. With chapters you can use multiselect. Ctrl+A also works. In many situations keys like Delete, Enter also work.


![](Home_2.png)
Multiselect, Delete key, Enter key work here.


![](Home_3.png)
There is resize control beetwen series and chapters. With chapters you can use multiselect. Ctrl+A also works. In many situations keys like Delete, Enter also work.


![](Home_4.png)
By default images will be downloaded to your desktop.
